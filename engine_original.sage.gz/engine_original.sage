# ============================================================
#                 LINE ARRANGEMENT EXPLORER
# ============================================================
#
# SageMath research code for experiments with projective line
# arrangements over Q.
#
# MAIN GOAL
# ------------------------------------------------------------
#
# Investigate parametrized families of line arrangements
#
#       L_i(n):
#           A(i,n)x + B(i,n)y + C(i,n)z = 0
#
# over Q, compute their exact combinatorics, Chern slopes,
# and experimentally investigate accumulation points.
#
#
# IMPORTANT MATHEMATICAL DATA
# ------------------------------------------------------------
#
# For an arrangement A of d distinct lines:
#
#       t_k = number of points lying on exactly k lines.
#
# Pair-count identity:
#
#       sum_{k >= 2} binomial(k,2) t_k = binomial(d,2).
#
# Logarithmic Chern numbers:
#
#       cbar_1^2 =
#           9 - 5d + sum_{m >= 2} (3m - 4)t_m
#
#       cbar_2 =
#           3 - 2d + sum_{m >= 2} (m - 1)t_m
#
# Chern slope:
#
#       cbar_1^2 / cbar_2.
#
#
# RESEARCH CONTEXT
# ------------------------------------------------------------
#
# The known rational right-triangle family has:
#
#       d = 8n
#
#       t_2       = 6n^2 + 6n - 8
#       t_3       = 2n^2 - 6n + 8
#       t_4       = 2n^2 + 2n - 3
#       t_(2n-1)  = 2
#       t_(2n+1)  = 2
#
# and slope
#
#       (38n^2 - 18n - 7)
#       ------------------
#       (16n^2 - 8n - 2)
#
# tending to
#
#       19/8 = 2.375.
#
# The conjectural upper endpoint is
#
#       5/2 = 2.5.
#
#
# EXACT ARITHMETIC
# ------------------------------------------------------------
#
# ALL mathematical calculations use QQ or ZZ.
#
# Never use Python floats for mathematical comparisons.
#
# Good:
#
#       QQ(19)/8
#       QQ(5)/2
#       QQ(1)/1000
#
# Also good:
#
#       exact_decimal("2.375")
#
# which returns exactly 19/8.
#
# Decimal approximations are generated only for DISPLAY,
# using a high-precision Sage RealField.
#
#
# PERFORMANCE
# ------------------------------------------------------------
#
# Intersection multiplicities are recovered from pair counts.
#
# Instead of:
#
#       pair intersections -> points -> test every point
#       against every line
#
# we count how many pairs produce each projective point.
#
# A point of multiplicity k occurs as an intersection of
#
#       binomial(k,2)
#
# pairs of lines.
#
# Thus the main intersection computation is O(d^2), rather
# than O(d^3).
#
# ============================================================


from sage.all import *

from collections import defaultdict
from decimal import Decimal
from itertools import product
import csv


# ============================================================
# 0. GLOBAL SETTINGS
# ============================================================

# Precision used ONLY for displaying decimal approximations.
DECIMAL_PRECISION = 200

RealHi = RealField(DECIMAL_PRECISION)


# Exact benchmark values
LOWER_ACCUMULATION_BOUND = QQ(2)

KNOWN_RATIONAL_BENCHMARK = QQ(19) / QQ(8)

CONJECTURED_UPPER_ENDPOINT = QQ(5) / QQ(2)


# ============================================================
# 1. EXACT NUMERICAL UTILITIES
# ============================================================

def exact_decimal(s):
    """
    Convert a terminating decimal string into an exact rational.

    Examples:
        exact_decimal("0.01")   -> 1/100
        exact_decimal("2.375")  -> 19/8
        exact_decimal("2.4375") -> 39/16
    """

    s = str(s).strip()

    d = Decimal(s)

    numerator, denominator = d.as_integer_ratio()

    return QQ(numerator) / QQ(denominator)


def decimal(q, digits=40):
    """
    Convert an exact rational into a high-precision decimal
    string for DISPLAY ONLY.

    None represents an undefined slope (e.g. 0/0).
    """

    if q is None:
        return "Undefined"

    if q == Infinity:
        return "Infinity"

    if q == -Infinity:
        return "-Infinity"

    x = RealHi(QQ(q))

    return str(x.n(digits))


def finite_rational(x):
    """
    Return True exactly when x is a finite rational.

    None means undefined.
    """

    return (
        x is not None
        and x != Infinity
        and x != -Infinity
    )


def exact_distance(a, b):
    """
    Exact absolute difference between two rational values.
    """

    return abs(QQ(a) - QQ(b))


# ============================================================
# 2. PROJECTIVE NORMALIZATION
# ============================================================

def normalize_projective_vector(v):
    """
    Normalize a nonzero vector in Q^3 up to nonzero scalar.

    Returns a canonical primitive integer tuple.

    Example:

        (1/2, 1, 3/2)

    becomes:

        (1, 2, 3)

    This is used both for lines and projective points.
    """

    v = vector(QQ, v)

    if all(x == 0 for x in v):
        raise ValueError(
            "Zero projective vector."
        )

    # Clear denominators
    denominator_lcm = lcm(
        [x.denominator() for x in v]
    )

    w = vector(
        ZZ,
        [
            ZZ(x * denominator_lcm)
            for x in v
        ]
    )

    # Divide by gcd
    nonzero = [
        abs(x)
        for x in w
        if x != 0
    ]

    if nonzero:

        g = gcd(nonzero)

        if g != 0:

            w = vector(
                ZZ,
                [
                    x // g
                    for x in w
                ]
            )

    # Fix sign.
    # The first nonzero coordinate must be positive.
    for x in w:

        if x != 0:

            if x < 0:
                w = -w

            break

    return tuple(w)


# ============================================================
# 3. PROJECTIVE GEOMETRY
# ============================================================

def line_intersection(L1, L2):
    """
    Intersection of two projective lines.

    A line

        A*x + B*y + C*z = 0

    is represented by (A,B,C).

    The intersection point is their cross product.

    Returns:
        normalized projective point

    or:
        None if the two lines coincide.
    """

    L1 = vector(QQ, L1)
    L2 = vector(QQ, L2)

    P = L1.cross_product(L2)

    if P == vector(QQ, [0, 0, 0]):
        return None

    return normalize_projective_vector(P)


def point_on_line(P, L):
    """
    Exact test whether projective point P lies on line L.
    """

    return (
        vector(QQ, P)
        .dot_product(vector(QQ, L))
        == 0
    )


# ============================================================
# 4. INTERSECTION MULTIPLICITY FROM PAIR COUNTS
# ============================================================

def multiplicity_from_pair_count(pair_count):
    """
    Given the number r of line pairs meeting at a projective
    point, recover the multiplicity k.

    Since

        r = binomial(k,2),

    we have

        k = (1 + sqrt(1 + 8r))/2.

    Everything is exact.
    """

    r = ZZ(pair_count)

    discriminant = ZZ(1) + ZZ(8) * r

    if not discriminant.is_square():

        raise ArithmeticError(
            "Invalid pair count %s: "
            "1 + 8r is not a square."
            % r
        )

    s = discriminant.sqrt()

    k_numerator = ZZ(1) + s

    if k_numerator % 2 != 0:

        raise ArithmeticError(
            "Invalid pair count %s."
            % r
        )

    k = k_numerator // 2

    if binomial(k, 2) != r:

        raise ArithmeticError(
            "Could not recover a valid multiplicity "
            "from pair count %s."
            % r
        )

    return ZZ(k)


# ============================================================
# 5. FAST INTERSECTION DATA
# ============================================================

def intersection_data(lines, store_points=True):
    """
    Compute intersection multiplicities using pair counting.

    This is O(d^2) rather than O(d^3).

    Returns:

        point_multiplicities
            point -> multiplicity

        tk
            k -> t_k

    If store_points=False, point_multiplicities is returned as
    None, but t_k is still computed.
    """

    d = len(lines)

    if d < 2:

        return {}, {}

    # --------------------------------------------------------
    # point_pair_counts[P] =
    #
    # number of unordered pairs of lines whose intersection
    # is P.
    # --------------------------------------------------------

    point_pair_counts = defaultdict(int)

    for i in range(d):

        for j in range(i + 1, d):

            P = line_intersection(
                lines[i],
                lines[j]
            )

            if P is None:

                raise ValueError(
                    "Coincident lines detected."
                )

            point_pair_counts[P] += 1

    # --------------------------------------------------------
    # Recover multiplicities from pair counts.
    # --------------------------------------------------------

    point_multiplicities = {}
    tk = defaultdict(int)

    for P, pair_count in point_pair_counts.items():

        k = multiplicity_from_pair_count(
            pair_count
        )

        if store_points:

            point_multiplicities[P] = k

        tk[k] += 1

    tk = dict(sorted(tk.items()))

    # --------------------------------------------------------
    # Fundamental pair-count consistency check.
    #
    # sum C(k,2)t_k = C(d,2)
    # --------------------------------------------------------

    lhs = sum(
        binomial(k, 2) * count
        for k, count in tk.items()
    )

    rhs = binomial(d, 2)

    if lhs != rhs:

        raise ArithmeticError(
            "Pair-count identity failed:\n"
            "    computed = %s\n"
            "    expected = %s"
            % (lhs, rhs)
        )

    if not store_points:

        point_multiplicities = None

    return point_multiplicities, tk


# ============================================================
# 6. SLOW INCIDENCE CHECK
# ============================================================

def verify_incidence_slow(lines, tk):
    """
    Independent O(d^3)-style verification.

    This is intentionally slower than the production algorithm
    and is mainly useful for debugging small arrangements.

    Returns True if the multiplicity data agrees.
    """

    points = set()

    d = len(lines)

    for i in range(d):

        for j in range(i + 1, d):

            P = line_intersection(
                lines[i],
                lines[j]
            )

            if P is not None:
                points.add(P)

    recomputed_tk = defaultdict(int)

    for P in points:

        k = sum(
            1
            for L in lines
            if point_on_line(P, L)
        )

        recomputed_tk[k] += 1

    recomputed_tk = dict(
        sorted(recomputed_tk.items())
    )

    return recomputed_tk == dict(
        sorted(tk.items())
    )


# ============================================================
# 7. ARRANGEMENT VALIDATION
# ============================================================

def arrangement_statistics(lines):
    """
    Normalize all lines and identify duplicates.

    Returns:

        d
        raw_number_of_lines
        duplicate_lines
        lines
    """

    normalized = [
        normalize_projective_vector(L)
        for L in lines
    ]

    distinct_lines = list(
        dict.fromkeys(normalized)
    )

    d = len(distinct_lines)

    duplicate_lines = (
        len(normalized) - d
    )

    return {
        "d": d,
        "raw_number_of_lines": len(normalized),
        "duplicate_lines": duplicate_lines,
        "lines": distinct_lines,
    }


def basic_combinatorial_checks(lines, tk):
    """
    Run basic exact consistency checks.

    Returns a dictionary of boolean results.
    """

    d = len(lines)

    pair_identity = (
        sum(
            binomial(k, 2) * count
            for k, count in tk.items()
        )
        == binomial(d, 2)
    )

    all_multiplicities_valid = all(
        k >= 2
        for k in tk
    )

    max_multiplicity_valid = (
        max(tk.keys(), default=1)
        <= d
    )

    return {
        "pair_identity": pair_identity,
        "all_multiplicities_ge_2":
            all_multiplicities_valid,
        "max_multiplicity_le_d":
            max_multiplicity_valid,
        "all_checks_pass":
            (
                pair_identity
                and all_multiplicities_valid
                and max_multiplicity_valid
            ),
    }


# ============================================================
# 8. CHERN NUMBERS
# ============================================================

def log_chern_numbers(lines, tk):
    """
    Exact logarithmic Chern numbers.

        cbar_1^2 =
            9 - 5d
            + sum_{m >= 2}(3m - 4)t_m

        cbar_2 =
            3 - 2d
            + sum_{m >= 2}(m - 1)t_m
    """

    d = ZZ(len(lines))

    c1 = (
        ZZ(9)
        - ZZ(5) * d
        + sum(
            ZZ(3*m - 4) * ZZ(count)
            for m, count in tk.items()
            if m >= 2
        )
    )

    c2 = (
        ZZ(3)
        - ZZ(2) * d
        + sum(
            ZZ(m - 1) * ZZ(count)
            for m, count in tk.items()
            if m >= 2
        )
    )

    return ZZ(c1), ZZ(c2)


def chern_slope(lines, tk):
    """
    Exact Chern slope:

        cbar_1^2 / cbar_2

    Returns:
        exact QQ value if cbar_2 != 0
        Infinity if cbar_2 = 0 and cbar_1^2 > 0
        -Infinity if cbar_2 = 0 and cbar_1^2 < 0
        None if cbar_1^2 = cbar_2 = 0
    """

    c1, c2 = log_chern_numbers(
        lines,
        tk
    )

    if c2 == 0:

        if c1 > 0:
            return Infinity

        if c1 < 0:
            return -Infinity

        return None

    return QQ(c1) / QQ(c2)


# ============================================================
# 9. COMBINATORIAL SIGNATURE
# ============================================================

def combinatorial_signature(tk):
    """
    Canonical representation of the multiplicity data.

    Example:

        {2:10, 3:4, 5:1}

    becomes:

        ((2,10), (3,4), (5,1))
    """

    return tuple(
        (k, tk[k])
        for k in sorted(tk)
    )


# ============================================================
# COMBINATORIAL SUMMARY DATA
# ============================================================

def multiplicity_spectrum(tk):
    """
    Return the multiplicities that actually occur.

    Example:

        {2: 10, 3: 4, 7: 1}

    gives:

        (2, 3, 7)
    """

    return tuple(
        sorted(tk.keys())
    )


def combinatorial_totals(tk):
    """
    Compute useful aggregate combinatorial statistics.

        f_0 = total number of singular/intersection points
        f_1 = total line-incidences at intersection points

    Also returns the total number of line-pairs represented
    by the t_k data.
    """

    f0 = sum(
        tk.values()
    )

    f1 = sum(
        k * t
        for k, t in tk.items()
    )

    pair_count = sum(
        binomial(k, 2) * t
        for k, t in tk.items()
    )

    return {
        "f0": ZZ(f0),
        "f1": ZZ(f1),
        "pair_count": ZZ(pair_count),
    }


def standard_geography_condition(lines, tk):
    """
    Check the standard line-arrangement condition

        t_d = 0
        t_{d-1} = 0.

    This is deliberately named as a CONDITION rather than
    claiming that every other hypothesis of every geography
    theorem has been verified.
    """

    d = len(lines)

    return (
        tk.get(d, 0) == 0
        and
        tk.get(d - 1, 0) == 0
    )


# Backwards-compatible alias for old code.
def geography_admissible(lines, tk):
    return standard_geography_condition(
        lines,
        tk
    )


# ============================================================
# 10. FAMILY GENERATOR CONVENTION
# ============================================================
#
# Every family generator should have the form:
#
#       def family_X(n, **params):
#           ...
#
# and return a list of triples
#
#       (A, B, C)
#
# representing
#
#       A*x + B*y + C*z = 0.
#
#
# The **params mechanism lets us later investigate families
# with extra parameters without redesigning the database.
# ============================================================


# ============================================================
# 11. EXPERIMENTAL FAMILIES
# ============================================================

def family_A(n, **params):
    """
    Family A:

        L_i(n):
            x + i*y + i^2*z = 0

    i = 0,...,n-1.
    """

    n = Integer(n)

    return [
        (
            QQ(1),
            QQ(i),
            QQ(i)^2
        )
        for i in range(n)
    ]


def family_B(n, **params):
    """
    Family B:

        L_i(n):
            x + i*y + n*i*z = 0

    i = 0,...,n-1.
    """

    n = Integer(n)

    return [
        (
            QQ(1),
            QQ(i),
            QQ(n) * QQ(i)
        )
        for i in range(n)
    ]


def family_C(n, **params):
    """
    Family C:

        L_i(n):
            i*x + y + i^2*z = 0

    i = 1,...,n.
    """

    n = Integer(n)

    return [
        (
            QQ(i),
            QQ(1),
            QQ(i)^2
        )
        for i in range(1, n + 1)
    ]


def family_D(n, **params):
    """
    Family D:

        L_i(n):
            x + (i^2+n)y + i*z = 0

    i = 0,...,n-1.
    """

    n = Integer(n)

    return [
        (
            QQ(1),
            QQ(i)^2 + QQ(n),
            QQ(i)
        )
        for i in range(n)
    ]


def family_E(n, **params):
    """
    Family E:

        L_i(n):
            (i+n)x + i^2*y + z = 0

    i = 0,...,n-1.
    """

    n = Integer(n)

    return [
        (
            QQ(i) + QQ(n),
            QQ(i)^2,
            QQ(1)
        )
        for i in range(n)
    ]


# ============================================================
# 12. KNOWN RATIONAL RIGHT-TRIANGLE FAMILY
# ============================================================

def family_RT(n, **params):
    r"""
    Known rational right-triangle family.

    For n >= 3:

        y = alpha*z/2
        x = alpha*z/2

        y = x + (beta-n+1)z
        y = -x + (beta+1)z

    where

        alpha = 0,...,2n

        beta = 0,...,2n-2.

    Total:

        d = 8n.

    All coefficients are rational.
    """

    n = Integer(n)

    if n < 3:
        return []

    lines = []

    # --------------------------------------------------------
    # y = alpha*z/2
    #
    # y - alpha*z/2 = 0
    #
    # --------------------------------------------------------

    for alpha in range(0, 2*n + 1):

        lines.append(
            (
                QQ(0),
                QQ(1),
                -QQ(alpha) / QQ(2)
            )
        )

    # --------------------------------------------------------
    # x = alpha*z/2
    #
    # x - alpha*z/2 = 0
    # --------------------------------------------------------

    for alpha in range(0, 2*n + 1):

        lines.append(
            (
                QQ(1),
                QQ(0),
                -QQ(alpha) / QQ(2)
            )
        )

    # --------------------------------------------------------
    # y = x + (beta-n+1)z
    #
    # -x + y - (beta-n+1)z = 0
    # --------------------------------------------------------

    for beta in range(0, 2*n - 1):

        lines.append(
            (
                QQ(-1),
                QQ(1),
                -QQ(beta - n + 1)
            )
        )

    # --------------------------------------------------------
    # y = -x + (beta+1)z
    #
    # x + y - (beta+1)z = 0
    # --------------------------------------------------------

    for beta in range(0, 2*n - 1):

        lines.append(
            (
                QQ(1),
                QQ(1),
                -QQ(beta + 1)
            )
        )

    return lines


# ============================================================
# 13. FAMILY DATABASE
# ============================================================

FAMILY_DATABASE = {

    "A": {
        "name":
            "Quadratic coefficient family",

        "description":
            "L_i(n): x + i*y + i^2*z = 0",

        "index_range":
            "i = 0,...,n-1",

        "function":
            family_A,

        "category":
            "experimental",

        "field":
            "Q",

        "parameters":
            [],

        "min_n":
            1,

        "d_formula":
            lambda n, **params: Integer(n),

        "notes":
            "Basic polynomial-coefficient experiment."
    },


    "B": {
        "name":
            "n-dependent quadratic family",

        "description":
            "L_i(n): x + i*y + n*i*z = 0",

        "index_range":
            "i = 0,...,n-1",

        "function":
            family_B,

        "category":
            "experimental",

        "field":
            "Q",

        "parameters":
            [],

        "min_n":
            1,

        "d_formula":
            lambda n, **params: Integer(n),

        "notes":
            "Both i and n enter the coefficients."
    },


    "C": {
        "name":
            "Dual quadratic family",

        "description":
            "L_i(n): i*x + y + i^2*z = 0",

        "index_range":
            "i = 1,...,n",

        "function":
            family_C,

        "category":
            "experimental",

        "field":
            "Q",

        "parameters":
            [],

        "min_n":
            1,

        "d_formula":
            lambda n, **params: Integer(n),

        "notes":
            "Control family with coefficients rearranged."
    },


    "D": {
        "name":
            "Shifted quadratic family",

        "description":
            "L_i(n): x + (i^2+n)y + i*z = 0",

        "index_range":
            "i = 0,...,n-1",

        "function":
            family_D,

        "category":
            "experimental",

        "field":
            "Q",

        "parameters":
            [],

        "min_n":
            1,

        "d_formula":
            lambda n, **params: Integer(n),

        "notes":
            "Quadratic family with explicit n-dependence."
    },


    "E": {
        "name":
            "Translated polynomial family",

        "description":
            "L_i(n): (i+n)x + i^2*y + z = 0",

        "index_range":
            "i = 0,...,n-1",

        "function":
            family_E,

        "category":
            "experimental",

        "field":
            "Q",

        "parameters":
            [],

        "min_n":
            1,

        "d_formula":
            lambda n, **params: Integer(n),

        "notes":
            "Control family."
    },


    "RT": {
        "name":
            "Known rational right-triangle family",

        "description":
            "y=alpha*z/2; x=alpha*z/2; "
            "y=x+(beta-n+1)z; "
            "y=-x+(beta+1)z",

        "index_range":
            "alpha=0,...,2n; beta=0,...,2n-2",

        "function":
            family_RT,

        "category":
            "known",

        "field":
            "Q",

        "parameters":
            [],

        "min_n":
            3,

        "d_formula":
            lambda n, **params: Integer(8) * Integer(n),

        "notes":
            "Published rational benchmark with limit 19/8."
    },
}


# ============================================================
# 14. ADD A NEW FAMILY
# ============================================================

def add_family(
    key,
    name,
    description,
    index_range,
    function,
    category="experimental",
    field="Q",
    parameters=None,
    min_n=1,
    d_formula=None,
    notes=""
):
    """
    Add a family to the database.

    d_formula, when supplied, should be a function of the form

        d_formula(n, **params)

    returning the expected number of distinct lines.
    """

    if key in FAMILY_DATABASE:

        raise ValueError(
            "Family '%s' already exists."
            % key
        )

    if parameters is None:
        parameters = []

    FAMILY_DATABASE[key] = {

        "name":
            name,

        "description":
            description,

        "index_range":
            index_range,

        "function":
            function,

        "category":
            category,

        "field":
            field,

        "parameters":
            parameters,

        "min_n":
            Integer(min_n),

        "d_formula":
            d_formula,

        "notes":
            notes,
    }


# ============================================================
# 15. LIST FAMILY DATABASE
# ============================================================

def list_families():
    """
    Print every registered family.
    """

    print()
    print("=" * 100)
    print("PARAMETRIZED FAMILY DATABASE")
    print("=" * 100)

    for key, data in FAMILY_DATABASE.items():

        print()

        print(
            "[%s] %s"
            % (
                key,
                data["name"]
            )
        )

        print(
            "    Category:",
            data["category"]
        )

        print(
            "    Field:",
            data["field"]
        )

        print(
            "    Equation:",
            data["description"]
        )

        print(
            "    Index:",
            data["index_range"]
        )

        if data["parameters"]:

            print(
                "    Extra parameters:",
                data["parameters"]
            )

        if data["notes"]:

            print(
                "    Notes:",
                data["notes"]
            )

    print()
    print("=" * 100)


# ============================================================
# 16. SHOW ONE FAMILY
# ============================================================

def show_family(key):
    """
    Print the exact parametrization of one family.
    """

    if key not in FAMILY_DATABASE:

        raise ValueError(
            "Unknown family '%s'."
            % key
        )

    data = FAMILY_DATABASE[key]

    print()
    print("=" * 100)
    print(
        "FAMILY %s"
        % key
    )
    print("=" * 100)

    print()
    print("Name:")
    print("    %s" % data["name"])

    print()
    print("Category:")
    print("    %s" % data["category"])

    print()
    print("Field:")
    print("    %s" % data["field"])

    print()
    print("Equation:")
    print("    %s" % data["description"])

    print()
    print("Index range:")
    print("    %s" % data["index_range"])

    if data["parameters"]:

        print()
        print("Extra parameters:")
        print(
            "    %s"
            % data["parameters"]
        )

    if data["notes"]:

        print()
        print("Notes:")
        print("    %s" % data["notes"])

    print()
    print("Generator:")
    print(
        "    %s(n, **params)"
        % data["function"].__name__
    )

    print()
    print("=" * 100)


# ============================================================
# 17. GENERATE AN ARRANGEMENT
# ============================================================

def generate_family(
    key,
    n,
    family_params=None
):
    """
    Generate a family at parameter n.

    Checks:

        * parameter domain
        * duplicate lines
        * optional expected d(n)
    """

    if key not in FAMILY_DATABASE:

        raise ValueError(
            "Unknown family '%s'."
            % key
        )

    if family_params is None:
        family_params = {}

    n = Integer(n)

    data = FAMILY_DATABASE[key]

    min_n = Integer(
        data.get("min_n", 1)
    )

    if n < min_n:

        raise ValueError(
            "Family %s is defined only for n >= %s."
            % (
                key,
                min_n
            )
        )

    function = data["function"]

    raw_lines = function(
        n,
        **family_params
    )

    stats = arrangement_statistics(
        raw_lines
    )

    if stats["duplicate_lines"] > 0:

        raise ValueError(
            "Family %s at n=%s contains %s "
            "duplicate projective lines."
            % (
                key,
                n,
                stats["duplicate_lines"]
            )
        )

    lines = stats["lines"]

    # --------------------------------------------------------
    # Optional independent expected-d validation.
    # --------------------------------------------------------

    d_formula = data.get(
        "d_formula",
        None
    )

    if d_formula is not None:

        expected_d = Integer(
            d_formula(
                n,
                **family_params
            )
        )

        actual_d = Integer(
            len(lines)
        )

        if actual_d != expected_d:

            raise ArithmeticError(
                "Family %s failed d(n) validation at n=%s:\n"
                "    expected d(n) = %s\n"
                "    actual d(n)   = %s"
                % (
                    key,
                    n,
                    expected_d,
                    actual_d
                )
            )

    return lines


# ============================================================
# 18. PRINT ACTUAL LINES
# ============================================================

def print_family_lines(
    key,
    n,
    family_params=None
):
    """
    Print the actual projective lines generated by a family.
    """

    lines = generate_family(
        key,
        n,
        family_params
    )

    data = FAMILY_DATABASE[key]

    print()
    print("=" * 100)
    print(
        "FAMILY %s AT n = %s"
        % (
            key,
            n
        )
    )
    print("=" * 100)

    print()
    print("Parametrization:")
    print(
        "    %s"
        % data["description"]
    )

    print()
    print("Generated lines:")

    for j, L in enumerate(lines):

        A, B, C = L

        print(
            "    L_%d : (%s)x + (%s)y + (%s)z = 0"
            % (
                j,
                A,
                B,
                C
            )
        )

    print()
    print(
        "Total distinct lines:",
        len(lines)
    )

    print()


# ============================================================
# 19. ANALYZE ONE INSTANCE
# ============================================================

def analyze_family_at_n(
    key,
    n,
    family_params=None,
    store_points=True,
    run_slow_check=False
):
    """
    Completely analyze one family at one parameter n.

    Returns a dictionary containing all exact data.
    """

    if family_params is None:
        family_params = {}

    lines = generate_family(
        key,
        n,
        family_params
    )

    d = len(lines)

    if d < 2:

        return {
            "valid": False,
            "family": key,
            "n": n,
            "reason":
                "Fewer than two distinct lines.",
        }

    points, tk = intersection_data(
        lines,
        store_points=store_points
    )

    c1, c2 = log_chern_numbers(
        lines,
        tk
    )

    slope = chern_slope(
        lines,
        tk
    )

    combinatorial = combinatorial_totals(
        tk
    )

    standard_geo = standard_geography_condition(
        lines,
        tk
    )

    c2_positive = (
        c2 > 0
    )

    chern_slope_relevant = (
        standard_geo
        and c2_positive
        and finite_rational(slope)
    )

    checks = basic_combinatorial_checks(
        lines,
        tk
    )

    if run_slow_check:

        slow_check = verify_incidence_slow(
            lines,
            tk
        )

    else:

        slow_check = None

    result = {

        "valid":
            True,

        "family":
            key,

        "family_name":
            FAMILY_DATABASE[key]["name"],

        "n":
            Integer(n),

        "family_params":
            dict(family_params),

        "d":
            Integer(d),

        "tk":
            dict(sorted(tk.items())),

        "multiplicity_spectrum":
            multiplicity_spectrum(tk),

        "f0":
            combinatorial["f0"],

        "f1":
            combinatorial["f1"],

        "pair_count":
            combinatorial["pair_count"],

        "t_d":
            tk.get(d, 0),

        "t_d_minus_1":
            tk.get(d - 1, 0),

        "c1bar2":
            c1,

        "c2bar":
            c2,

        "c2_positive":
            c2_positive,

        "slope":
            slope,

        "slope_decimal":
            decimal(slope, 50),

        "standard_geography_condition":
            standard_geo,

        # Backwards compatibility:
        "geography_admissible":
            standard_geo,

        "chern_slope_relevant":
            chern_slope_relevant,

        "signature":
            combinatorial_signature(tk),

        "checks":
            checks,

        "slow_incidence_check":
            slow_check,

        "points":
            points,

        "lines":
            lines,
    }

    return result


# ============================================================
# 20. PRINT ONE RESULT
# ============================================================

def print_result(result):
    """
    Human-readable display of one exact result.
    """

    if not result["valid"]:

        print()
        print("INVALID RESULT")

        print(
            "Family:",
            result["family"]
        )

        print(
            "n:",
            result["n"]
        )

        print(
            "Reason:",
            result["reason"]
        )

        return

    key = result["family"]

    data = FAMILY_DATABASE[key]

    print()
    print("=" * 100)

    print(
        "FAMILY %s | n = %s"
        % (
            key,
            result["n"]
        )
    )

    print("=" * 100)

    print()
    print("PARAMETRIZATION")
    print("----------------")

    print(
        "    %s"
        % data["description"]
    )

    print(
        "    %s"
        % data["index_range"]
    )

    if result["family_params"]:

        print()
        print("Extra parameters:")
        print(
            "    %s"
            % result["family_params"]
        )

    print()
    print("ARRANGEMENT")
    print("-----------")

    print(
        "    Number of lines d =",
        result["d"]
    )

    print(
        "    t_d =",
        result["t_d"]
    )

    print(
        "    t_(d-1) =",
        result["t_d_minus_1"]
    )

    print(
        "    Standard geography condition =",
        result[
            "standard_geography_condition"
        ]
    )

    print(
        "    cbar_2 > 0 =",
        result[
            "c2_positive"
        ]
    )

    print(
        "    Chern-slope relevant =",
        result[
            "chern_slope_relevant"
        ]
    )

    print()
    print("COMBINATORIAL SUMMARY")
    print("---------------------")

    print(
        "    f_0 =",
        result["f0"]
    )

    print(
        "    f_1 =",
        result["f1"]
    )

    print(
        "    pair count =",
        result["pair_count"]
    )

    print(
        "    multiplicity spectrum =",
        result["multiplicity_spectrum"]
    )

    print()
    print("INTERSECTION MULTIPLICITIES")
    print("----------------------------")

    for k in sorted(result["tk"]):

        print(
            "    t_%d = %d"
            % (
                k,
                result["tk"][k]
            )
        )

    print()
    print("CHERN NUMBERS")
    print("-------------")

    print(
        "    cbar_1^2 =",
        result["c1bar2"]
    )

    print(
        "    cbar_2   =",
        result["c2bar"]
    )

    print()
    print("CHERN SLOPE")
    print("-----------")

    print(
        "    exact   =",
        result["slope"]
    )

    print(
        "    decimal =",
        result["slope_decimal"]
    )

    print()
    print("COMBINATORIAL CHECKS")
    print("--------------------")

    for name, value in result["checks"].items():

        print(
            "    %-30s : %s"
            % (
                name,
                value
            )
        )

    if result["slow_incidence_check"] is not None:

        print()
        print(
            "Slow incidence check:",
            result["slow_incidence_check"]
        )

    print()
    print("SIGNATURE")
    print("---------")

    print(
        "    %s"
        % (
            result["signature"],
        )
    )

    print()
    print("=" * 100)


# ============================================================
# 21. SEARCH ONE FAMILY
# ============================================================

def search_family(
    key,
    N=30,
    min_n=None,
    family_params=None,
    compute_points=True,
    verbose=True,
    stop_on_error=False,
    require_standard_geography=False,
    require_positive_c2=False,
    require_relevant_slope=False,
    error_log=None
):
    """
    Search

        n = min_n,...,N

    for one family.

    Results are returned as a list of dictionaries.
    Optional error_log list receives structured error records.
    """

    if key not in FAMILY_DATABASE:

        raise ValueError(
            "Unknown family '%s'."
            % key
        )

    if family_params is None:
        family_params = {}

    data = FAMILY_DATABASE[key]

    if min_n is None:
        min_n = data.get(
            "min_n",
            1
        )

    results = []

    for n in range(
        Integer(min_n),
        Integer(N) + 1
    ):

        try:

            result = analyze_family_at_n(
                key,
                n,
                family_params=family_params,
                store_points=compute_points
            )

            if not result["valid"]:
                continue

            if (
                require_standard_geography
                and not result[
                    "standard_geography_condition"
                ]
            ):
                continue

            if (
                require_positive_c2
                and not result[
                    "c2_positive"
                ]
            ):
                continue

            if (
                require_relevant_slope
                and not result[
                    "chern_slope_relevant"
                ]
            ):
                continue

            results.append(result)

            if verbose:
                print_result(result)

        except Exception as e:

            error_record = {
                "family": key,
                "n": n,
                "params": dict(family_params),
                "error_type": type(e).__name__,
                "error": str(e),
            }

            if error_log is not None:
                error_log.append(error_record)

            print()

            print(
                "ERROR: family=%s, n=%s"
                % (
                    key,
                    n
                )
            )

            print(
                "    %s"
                % e
            )

            if stop_on_error:
                raise

    return results


# ============================================================
# 22. SEARCH ALL REGISTERED FAMILIES
# ============================================================

def search_all_families(
    N=30,
    min_n=None,
    family_params_by_key=None,
    verbose=True
):
    """
    Search every registered family.

    family_params_by_key may be supplied as:

        {
            "A": {},
            "F": {"a": 2, "b": -1}
        }
    """

    if family_params_by_key is None:
        family_params_by_key = {}

    all_results = {}

    for key in FAMILY_DATABASE:

        params = family_params_by_key.get(
            key,
            {}
        )

        print()
        print("#" * 100)

        print(
            "SEARCHING FAMILY %s"
            % key
        )

        print("#" * 100)

        all_results[key] = search_family(
            key,
            N=N,
            min_n=min_n,
            family_params=params,
            verbose=verbose
        )

    return all_results


# ============================================================
# 23. SLOPE SEQUENCE
# ============================================================

def slope_sequence(
    key,
    N=50,
    min_n=None,
    family_params=None
):
    """
    Return:

        [(n, exact_slope), ...]

    """

    results = search_family(
        key,
        N=N,
        min_n=min_n,
        family_params=family_params,
        compute_points=False,
        verbose=False
    )

    return [
        (
            r["n"],
            r["slope"]
        )
        for r in results
    ]


# ============================================================
# 24. SLOPE TABLE
# ============================================================

def print_slope_table(
    key,
    N=30,
    min_n=None,
    family_params=None
):
    """
    Print exact and high-precision slope values.
    """

    seq = slope_sequence(
        key,
        N=N,
        min_n=min_n,
        family_params=family_params
    )

    print()
    print("=" * 100)

    print(
        "SLOPE TABLE -- FAMILY %s"
        % key
    )

    print("=" * 100)

    print()

    print(
        "%8s | %35s | %50s"
        % (
            "n",
            "exact slope",
            "decimal"
        )
    )

    print("-" * 100)

    for n, slope in seq:

        if finite_rational(slope):

            dec = decimal(
                slope,
                40
            )

        else:

            dec = str(slope)

        print(
            "%8d | %35s | %50s"
            % (
                n,
                slope,
                dec
            )
        )

    print()


# ============================================================
# 25. HIGH-SLOPE SEARCH
# ============================================================

def scan_for_high_slopes(
    threshold=KNOWN_RATIONAL_BENCHMARK,
    N=50,
    family_keys=None,
    family_params_by_key=None
):
    """
    Search for slopes strictly above a chosen threshold.

    Default:

        19/8.
    """

    threshold = QQ(threshold)

    if family_keys is None:

        family_keys = list(
            FAMILY_DATABASE.keys()
        )

    if family_params_by_key is None:

        family_params_by_key = {}

    hits = []

    print()
    print("=" * 100)
    print("HIGH-SLOPE SEARCH")
    print("=" * 100)

    print()
    print(
        "Threshold exact:",
        threshold
    )

    print(
        "Threshold decimal:",
        decimal(threshold, 50)
    )

    print()

    for key in family_keys:

        params = family_params_by_key.get(
            key,
            {}
        )

        results = search_family(
            key,
            N=N,
            family_params=params,
            compute_points=True,
            verbose=False
        )

        for r in results:

            slope = r["slope"]

            if not finite_rational(slope):
                continue

            if slope > threshold:

                hits.append(r)

                print(
                    "FOUND | "
                    "family=%s | n=%s | d=%s | "
                    "slope=%s | decimal=%s"
                    % (
                        key,
                        r["n"],
                        r["d"],
                        slope,
                        r["slope_decimal"]
                    )
                )

    print()
    print(
        "Total hits:",
        len(hits)
    )

    return hits


def scan_for_relevant_high_slopes(
    threshold=KNOWN_RATIONAL_BENCHMARK,
    N=50,
    family_keys=None,
    family_params_by_key=None
):
    """
    Search only arrangements satisfying:

        t_d = 0
        t_{d-1} = 0
        cbar_2 > 0

    and whose exact Chern slope exceeds threshold.
    """

    threshold = QQ(threshold)

    if family_keys is None:
        family_keys = list(
            FAMILY_DATABASE.keys()
        )

    if family_params_by_key is None:
        family_params_by_key = {}

    hits = []

    for key in family_keys:

        params = family_params_by_key.get(
            key,
            {}
        )

        results = search_family(
            key,
            N=N,
            family_params=params,
            compute_points=True,
            verbose=False,
            require_relevant_slope=True
        )

        for r in results:

            if r["slope"] > threshold:

                hits.append(r)

                print(
                    "PROMISING | "
                    "family=%s | n=%s | d=%s | "
                    "slope=%s | decimal=%s"
                    % (
                        key,
                        r["n"],
                        r["d"],
                        r["slope"],
                        r["slope_decimal"]
                    )
                )

    print()
    print(
        "Total relevant hits:",
        len(hits)
    )

    return hits


# ============================================================
# 26. TARGET SEARCH
# ============================================================

def scan_near_target(
    target=CONJECTURED_UPPER_ENDPOINT,
    tolerance=QQ(1) / QQ(1000),
    N=50,
    family_keys=None,
    family_params_by_key=None
):
    """
    Search for slopes satisfying

        |slope - target| <= tolerance.

    Everything is exact.
    """

    target = QQ(target)
    tolerance = QQ(tolerance)

    if family_keys is None:

        family_keys = list(
            FAMILY_DATABASE.keys()
        )

    if family_params_by_key is None:

        family_params_by_key = {}

    hits = []

    for key in family_keys:

        params = family_params_by_key.get(
            key,
            {}
        )

        results = search_family(
            key,
            N=N,
            family_params=params,
            compute_points=True,
            verbose=False
        )

        for r in results:

            slope = r["slope"]

            if not finite_rational(slope):
                continue

            distance = abs(
                slope - target
            )

            if distance <= tolerance:

                hits.append({
                    "family":
                        key,

                    "n":
                        r["n"],

                    "d":
                        r["d"],

                    "slope":
                        slope,

                    "distance":
                        distance,

                    "tk":
                        r["tk"],
                })

    hits.sort(
        key=lambda x: x["distance"]
    )

    print()
    print("=" * 100)
    print("SEARCH NEAR TARGET")
    print("=" * 100)

    print()
    print(
        "Target exact:",
        target
    )

    print(
        "Target decimal:",
        decimal(target, 50)
    )

    print(
        "Tolerance exact:",
        tolerance
    )

    print()

    for h in hits:

        print(
            "family=%s | n=%s | d=%s | "
            "slope=%s | distance=%s"
            % (
                h["family"],
                h["n"],
                h["d"],
                h["slope"],
                h["distance"]
            )
        )

    print()
    print(
        "Total hits:",
        len(hits)
    )

    return hits


# ============================================================
# 27. EXPERIMENTAL ACCUMULATION ANALYSIS
# ============================================================

def estimate_accumulation_point(
    key,
    N=100,
    tail=20,
    family_params=None
):
    """
    Numerically inspect the apparent tail behavior of one
    parametrized family.

    WARNING:
        This is experimental evidence, not a proof that the
        sequence converges.
    """

    seq = slope_sequence(
        key,
        N=N,
        family_params=family_params
    )

    finite_seq = [
        (n, s)
        for n, s in seq
        if finite_rational(s)
    ]

    if not finite_seq:
        return None

    tail = min(
        Integer(tail),
        len(finite_seq)
    )

    tail_data = finite_seq[-tail:]

    tail_values = [
        s
        for n, s in tail_data
    ]

    tail_real = [
        RealHi(s)
        for s in tail_values
    ]

    average = (
        sum(tail_real)
        / len(tail_real)
    )

    minimum = min(tail_real)
    maximum = max(tail_real)

    spread = maximum - minimum

    last_exact = tail_values[-1]

    first_n = finite_seq[0][0]
    last_n = finite_seq[-1][0]

    print()
    print("=" * 100)
    print(
        "EXPERIMENTAL ACCUMULATION ANALYSIS"
    )
    print("=" * 100)

    print()
    print(
        "Family:",
        key
    )

    print(
        "Equation:",
        FAMILY_DATABASE[key]["description"]
    )

    print()
    print(
        "Search range:",
        "n = %s,...,%s"
        % (
            first_n,
            last_n
        )
    )

    print()
    print(
        "Last exact slope:",
        last_exact
    )

    print(
        "Last decimal slope:",
        decimal(last_exact, 60)
    )

    print()
    print(
        "Tail average:"
    )

    print(
        "    %s"
        % average.n(60)
    )

    print()
    print(
        "Tail spread:"
    )

    print(
        "    %s"
        % spread.n(40)
    )

    print()
    print(
        "Known benchmark 19/8:"
    )

    print(
        "    %s"
        % decimal(
            KNOWN_RATIONAL_BENCHMARK,
            40
        )
    )

    print()
    print(
        "Distance of final slope from 19/8:"
    )

    print(
        "    %s"
        % decimal(
            abs(
                last_exact
                - KNOWN_RATIONAL_BENCHMARK
            ),
            40
        )
    )

    print()
    print(
        "Distance of final slope from 5/2:"
    )

    print(
        "    %s"
        % decimal(
            abs(
                last_exact
                - CONJECTURED_UPPER_ENDPOINT
            ),
            40
        )
    )

    print()
    print(
        "CAUTION:"
    )

    print(
        "    This is numerical reconnaissance only."
    )

    print()

    return {

        "family":
            key,

        "N":
            N,

        "tail":
            tail,

        "last_exact":
            last_exact,

        "tail_average":
            average,

        "tail_spread":
            spread,
    }


# ============================================================
# 28. EXACT RATIONAL LIMIT AT INFINITY
# ============================================================

def exact_rational_function_limit_at_infinity(
    numerator,
    denominator
):
    """
    Compute the exact limit at +infinity of a rational function
    whose numerator and denominator belong to the same
    univariate polynomial ring over QQ.

    If degrees are equal, the limit is the ratio of leading
    coefficients.

    If numerator degree < denominator degree:
        0.

    If numerator degree > denominator degree:
        +/- Infinity, when the sign can be determined.
    """

    numerator = numerator
    denominator = denominator

    if denominator == 0:

        raise ZeroDivisionError(
            "Denominator polynomial is zero."
        )

    numerator = numerator.parent()(numerator)
    denominator = numerator.parent()(denominator)

    deg_num = numerator.degree()
    deg_den = denominator.degree()

    if deg_num < deg_den:

        return QQ(0)

    if deg_num == deg_den:

        return QQ(
            numerator.leading_coefficient()
        ) / QQ(
            denominator.leading_coefficient()
        )

    # Degree numerator > denominator.
    #
    # For +infinity, the signs are determined by leading
    # coefficients because the leading powers dominate.

    sign = (
        numerator.leading_coefficient()
        /
        denominator.leading_coefficient()
    )

    if sign > 0:

        return Infinity

    if sign < 0:

        return -Infinity

    return NaN


# ============================================================
# 29. SYMBOLIC CHERN DATA FROM FORMULAS
# ============================================================

def symbolic_chern_from_tk(
    d_formula,
    tk_formulas
):
    """
    Construct exact symbolic formulas from:

        d(n)

    and:

        {m(n): t_m(n)}

    The multiplicity key m may be either a constant integer
    or a polynomial expression such as 2*n - 1.
    """

    R = d_formula.parent()

    d = R(d_formula)

    c1 = R(
        9 - 5*d
    )

    c2 = R(
        3 - 2*d
    )

    for m, t_m in tk_formulas.items():

        m = R(m)
        t_m = R(t_m)

        c1 += (
            3*m - 4
        ) * t_m

        c2 += (
            m - 1
        ) * t_m

    c1 = R(c1)
    c2 = R(c2)

    if c2 == 0:

        slope = None
        exact_limit = None

    else:

        slope = c1 / c2

        exact_limit = (
            exact_rational_function_limit_at_infinity(
                c1,
                c2
            )
        )

    return {

        "d":
            d,

        "c1bar2":
            c1,

        "c2bar":
            c2,

        "slope":
            slope,

        "limit":
            exact_limit,
    }


# ============================================================
# 30. KNOWN RIGHT-TRIANGLE SYMBOLIC CHECK
# ============================================================

def verify_RT_symbolically():
    """
    Verify the published symbolic RT formulas.

    Expected slope:

        (38n^2 - 18n - 7)
        ------------------
        (16n^2 - 8n - 2)

    Expected limit:

        19/8.
    """

    R = PolynomialRing(
        QQ,
        "n"
    )

    n = R.gen()

    d = 8*n

    tk = {

        2:
            6*n^2 + 6*n - 8,

        3:
            2*n^2 - 6*n + 8,

        4:
            2*n^2 + 2*n - 3,

        2*n - 1:
            R(2),

        2*n + 1:
            R(2),
    }

    data = symbolic_chern_from_tk(
        d,
        tk
    )

    expected_slope = (
        38*n^2 - 18*n - 7
    ) / (
        16*n^2 - 8*n - 2
    )

    expected_limit = QQ(19) / QQ(8)

    slope_difference = (
        data["slope"]
        - expected_slope
    )

    limit_difference = (
        data["limit"]
        - expected_limit
    )

    print()
    print("=" * 100)
    print("SYMBOLIC RIGHT-TRIANGLE BENCHMARK")
    print("=" * 100)

    print()
    print(
        "Computed d(n):"
    )

    print(
        "    %s"
        % data["d"]
    )

    print()
    print(
        "Computed cbar_1^2(n):"
    )

    print(
        "    %s"
        % data["c1bar2"]
    )

    print()
    print(
        "Computed cbar_2(n):"
    )

    print(
        "    %s"
        % data["c2bar"]
    )

    print()
    print(
        "Computed slope:"
    )

    print(
        "    %s"
        % data["slope"]
    )

    print()
    print(
        "Expected slope:"
    )

    print(
        "    %s"
        % expected_slope
    )

    print()
    print(
        "Slope difference:"
    )

    print(
        "    %s"
        % slope_difference
    )

    print()
    print(
        "Computed limit:"
    )

    print(
        "    %s"
        % data["limit"]
    )

    print()
    print(
        "Expected limit:"
    )

    print(
        "    %s"
        % expected_limit
    )

    print()
    print(
        "Symbolic slope correct:",
        slope_difference == 0
    )

    print(
        "Symbolic limit correct:",
        limit_difference == 0
    )

    print()

    return {

        "computed":
            data,

        "expected_slope":
            expected_slope,

        "expected_limit":
            expected_limit,

        "slope_correct":
            slope_difference == 0,

        "limit_correct":
            limit_difference == 0,
    }


# ============================================================
# 31. RIGHT-TRIANGLE BRUTE-FORCE VALIDATION
# ============================================================

def verify_RT_numerically(N=10):
    """
    Compare brute-force t_k computations with the published
    formulas for n = 3,...,N.
    """

    failures = []

    N = Integer(N)

    if N < 3:

        raise ValueError(
            "N must be at least 3."
        )

    for n in range(3, N + 1):

        result = analyze_family_at_n(
            "RT",
            n,
            store_points=False
        )

        computed = result["tk"]

        expected = {

            2:
                6*n^2 + 6*n - 8,

            3:
                2*n^2 - 6*n + 8,

            4:
                2*n^2 + 2*n - 3,

            2*n - 1:
                2,

            2*n + 1:
                2,
        }

        expected = dict(
            sorted(
                (
                    k,
                    v
                )
                for k, v in expected.items()
                if v != 0
            )
        )

        if computed != expected:

            failures.append({

                "n":
                    n,

                "computed":
                    computed,

                "expected":
                    expected,
            })

    print()
    print("=" * 100)
    print("BRUTE-FORCE RIGHT-TRIANGLE VALIDATION")
    print("=" * 100)

    if not failures:

        print()
        print(
            "SUCCESS"
        )

        print()
        print(
            "All tested values n=3,...,%d"
            % N
        )

        print(
            "match the known t_k formulas."
        )

    else:

        print()
        print(
            "FAILURES FOUND:"
        )

        for failure in failures:

            print()
            print(
                failure
            )

    print()

    return failures


# ============================================================
# 32. DISCOVER A LOW-DEGREE POLYNOMIAL FORMULA
# ============================================================

def discover_polynomial_formula(
    key,
    quantity="t_2",
    N=40,
    max_degree=8,
    min_n=None,
    family_params=None
):
    """
    Experimentally search for a LOW-DEGREE polynomial formula
    for d(n) or t_k(n).

    quantity examples:

        "d"
        "t_2"
        "t_3"
        "t_4"
        "t_5"

    Method:

        * take the first degree+1 values as interpolation data
        * test the resulting polynomial against ALL values
        * return the first polynomial that passes

    Thus the program is not simply fitting a degree N-1
    polynomial.

    IMPORTANT:
        A successful fit remains a conjecture until proved.
    """

    results = search_family(
        key,
        N=N,
        min_n=min_n,
        family_params=family_params,
        compute_points=True,
        verbose=False
    )

    if not results:

        print(
            "No data available."
        )

        return None

    data = []

    for r in results:

        n = ZZ(r["n"])

        if quantity == "d":

            value = ZZ(r["d"])

        elif quantity.startswith("t_"):

            k = Integer(
                quantity.split("_")[1]
            )

            value = ZZ(
                r["tk"].get(k, 0)
            )

        else:

            raise ValueError(
                "quantity must be 'd' or 't_k'."
            )

        data.append(
            (
                n,
                value
            )
        )

    R = PolynomialRing(
        QQ,
        "n"
    )

    nvar = R.gen()

    max_degree = min(
        Integer(max_degree),
        len(data) - 1
    )

    for degree in range(
        0,
        max_degree + 1
    ):

        interpolation_data = data[
            :degree + 1
        ]

        candidate = R.lagrange_polynomial(
            interpolation_data
        )

        valid = all(
            candidate(x) == y
            for x, y in data
        )

        if valid:

            print()
            print("=" * 100)

            print(
                "LOW-DEGREE FORMULA DISCOVERY"
            )

            print("=" * 100)

            print()
            print(
                "Family:",
                key
            )

            print(
                "Quantity:",
                quantity
            )

            print()
            print(
                "Candidate:"
            )

            print(
                "    %s(n) = %s"
                % (
                    quantity,
                    candidate
                )
            )

            print()
            print(
                "Degree:",
                degree
            )

            print()
            print(
                "Verified for all tested n = %s,...,%s"
                % (
                    data[0][0],
                    data[-1][0]
                )
            )

            print()
            print(
                "CAUTION:"
            )

            print(
                "    This is a computationally verified"
            )

            print(
                "    conjectural formula, not a proof."
            )

            print()

            return candidate

    print()
    print("=" * 100)

    print(
        "NO LOW-DEGREE FORMULA FOUND"
    )

    print("=" * 100)

    print()
    print(
        "Family:",
        key
    )

    print(
        "Quantity:",
        quantity
    )

    print(
        "Tested maximum degree:",
        max_degree
    )

    print(
        "Tested range:",
        "%s,...,%s"
        % (
            data[0][0],
            data[-1][0]
        )
    )

    print()

    return None


# ============================================================
# 33. INTERPOLATION WRAPPER
# ============================================================

def interpolate_tk(
    key,
    k,
    N=30,
    family_params=None
):
    """
    Convenience wrapper for discovering t_k(n).
    """

    return discover_polynomial_formula(
        key,
        quantity="t_%d" % Integer(k),
        N=N,
        family_params=family_params
    )


def interpolate_d(
    key,
    N=30,
    family_params=None
):
    """
    Convenience wrapper for discovering d(n).
    """

    return discover_polynomial_formula(
        key,
        quantity="d",
        N=N,
        family_params=family_params
    )


# ============================================================
# 34. PARAMETER-GRID SEARCH
# ============================================================

def parameter_grid(grid):
    """
    Turn a dictionary of parameter lists into a list of
    parameter dictionaries.

    Example:

        parameter_grid({
            "a": [-1,0,1],
            "b": [0,1]
        })

    produces all 6 combinations.
    """

    names = list(
        grid.keys()
    )

    value_lists = [
        grid[name]
        for name in names
    ]

    combinations = []

    for values in product(*value_lists):

        combinations.append(
            dict(
                zip(
                    names,
                    values
                )
            )
        )

    return combinations


def search_parameter_grid(
    key,
    grid,
    N=30,
    min_n=None,
    threshold=None,
    verbose=False
):
    """
    Search a multi-parameter family over a finite parameter
    grid.

    Example family:

        def family_F(n, a=0, b=0):
            ...

    Example search:

        search_parameter_grid(
            "F",
            {
                "a": range(-2,3),
                "b": range(-2,3)
            },
            N=50
        )
    """

    parameter_choices = parameter_grid(
        grid
    )

    all_results = []

    print()
    print("=" * 100)

    print(
        "MULTI-PARAMETER SEARCH"
    )

    print("=" * 100)

    print()
    print(
        "Family:",
        key
    )

    print(
        "Parameter combinations:",
        len(parameter_choices)
    )

    print()

    for params in parameter_choices:

        if verbose:

            print(
                "Testing parameters:",
                params
            )

        results = search_family(
            key,
            N=N,
            min_n=min_n,
            family_params=params,
            compute_points=False,
            verbose=False
        )

        for r in results:

            if threshold is None:

                all_results.append(r)

            else:

                if (
                    finite_rational(r["slope"])
                    and
                    r["slope"] > QQ(threshold)
                ):

                    all_results.append(r)

    if threshold is not None:

        print(
            "Threshold:",
            QQ(threshold)
        )

    print(
        "Total results retained:",
        len(all_results)
    )

    print()

    return all_results


# ============================================================
# 35. EXPORT RESULTS TO CSV
# ============================================================

def export_results_csv(
    results,
    filename
):
    """
    Export a list of result dictionaries to CSV.

    Exact rational values are stored as strings.

    This avoids introducing floating-point approximations
    into the saved research data.
    """

    if not results:

        raise ValueError(
            "No results to export."
        )

    fieldnames = [

        "family",
        "family_name",
        "n",
        "d",

        "f0",
        "f1",
        "pair_count",
        "multiplicity_spectrum",

        "t_d",
        "t_d_minus_1",

        "standard_geography_condition",
        "c2_positive",
        "chern_slope_relevant",

        "c1bar2",
        "c2bar",

        "slope",
        "slope_decimal",

        "signature",
    ]

    with open(
        filename,
        "w",
        newline=""
    ) as f:

        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames
        )

        writer.writeheader()

        for r in results:

            row = {

                "family":
                    r.get("family", ""),

                "family_name":
                    r.get("family_name", ""),

                "n":
                    str(r.get("n", "")),

                "d":
                    str(r.get("d", "")),

                "f0":
                    str(r.get("f0", "")),

                "f1":
                    str(r.get("f1", "")),

                "pair_count":
                    str(r.get("pair_count", "")),

                "multiplicity_spectrum":
                    str(
                        r.get(
                            "multiplicity_spectrum",
                            ""
                        )
                    ),

                "t_d":
                    str(r.get("t_d", "")),

                "t_d_minus_1":
                    str(
                        r.get(
                            "t_d_minus_1",
                            ""
                        )
                    ),

                "standard_geography_condition":
                    str(
                        r.get(
                            "standard_geography_condition",
                            ""
                        )
                    ),

                "c2_positive":
                    str(
                        r.get(
                            "c2_positive",
                            ""
                        )
                    ),

                "chern_slope_relevant":
                    str(
                        r.get(
                            "chern_slope_relevant",
                            ""
                        )
                    ),

                "c1bar2":
                    str(
                        r.get(
                            "c1bar2",
                            ""
                        )
                    ),

                "c2bar":
                    str(
                        r.get(
                            "c2bar",
                            ""
                        )
                    ),

                "slope":
                    str(
                        r.get(
                            "slope",
                            ""
                        )
                    ),

                "slope_decimal":
                    str(
                        r.get(
                            "slope_decimal",
                            ""
                        )
                    ),

                "signature":
                    str(
                        r.get(
                            "signature",
                            ""
                        )
                    ),
            }

            writer.writerow(row)

    print(
        "Exported %d results to %s"
        % (
            len(results),
            filename
        )
    )


# ============================================================
# 36. QUICK FAMILY EXPERIMENT
# ============================================================

def experiment(
    key,
    N=50,
    tail=20,
    family_params=None
):
    """
    Convenient three-stage experiment:

        1. show family
        2. print slope table
        3. estimate tail behavior
    """

    show_family(key)

    print_slope_table(
        key,
        N=N,
        family_params=family_params
    )

    return estimate_accumulation_point(
        key,
        N=N,
        tail=min(tail, N),
        family_params=family_params
    )


# ============================================================
# 37. FULL FAMILY REPORT
# ============================================================

def research_report(
    key,
    N=50,
    family_params=None
):
    """
    Compact research-oriented report.

    Gives:

        * family
        * d(n)
        * observed t_k
        * slope at final n
        * apparent tail
        * comparison with 19/8
        * comparison with 5/2
    """

    show_family(key)

    print()
    print("=" * 100)
    print(
        "RESEARCH REPORT -- FAMILY %s"
        % key
    )
    print("=" * 100)

    results = search_family(
        key,
        N=N,
        family_params=family_params,
        compute_points=False,
        verbose=False
    )

    if not results:

        print(
            "No valid arrangements found."
        )

        return None

    last = results[-1]

    print()
    print(
        "Last tested parameter n:",
        last["n"]
    )

    print(
        "Number of lines d:",
        last["d"]
    )

    print()
    print(
        "Last t_k signature:"
    )

    print(
        "    %s"
        % (
            last["signature"],
        )
    )

    print()
    print(
        "Last Chern slope:"
    )

    print(
        "    exact:",
        last["slope"]
    )

    print(
        "    decimal:",
        last["slope_decimal"]
    )

    print()
    print(
        "Relative to known rational benchmark 19/8:"
    )

    if finite_rational(last["slope"]):

        difference_19_8 = (
            last["slope"]
            - KNOWN_RATIONAL_BENCHMARK
        )

        print(
            "    slope - 19/8 =",
            difference_19_8
        )

        print(
            "    decimal =",
            decimal(
                difference_19_8,
                40
            )
        )

    else:

        print(
            "    undefined / non-finite slope"
        )

    print()
    print(
        "Relative to conjectured endpoint 5/2:"
    )

    if finite_rational(last["slope"]):

        difference_5_2 = (
            last["slope"]
            - CONJECTURED_UPPER_ENDPOINT
        )

        print(
            "    slope - 5/2 =",
            difference_5_2
        )

        print(
            "    decimal =",
            decimal(
                difference_5_2,
                40
            )
        )

    else:

        print(
            "    undefined / non-finite slope"
        )

    print()

    accumulation = estimate_accumulation_point(
        key,
        N=N,
        tail=min(20, N),
        family_params=family_params
    )

    return {
        "last_result":
            last,

        "accumulation":
            accumulation,
    }


# ============================================================
# 38. SELF TESTS
# ============================================================

def run_self_tests(
    RT_N=8
):
    """
    Run the main internal consistency tests.

    Recommended after loading/changing the file.
    """

    print()
    print("#" * 100)
    print("RUNNING SELF TESTS")
    print("#" * 100)

    # --------------------------------------------------------
    # Exact decimal parser
    # --------------------------------------------------------

    print()
    print("Test 1: exact decimal parser")

    assert (
        exact_decimal("0.01")
        == QQ(1) / QQ(100)
    )

    assert (
        exact_decimal("2.375")
        == QQ(19) / QQ(8)
    )

    assert (
        exact_decimal("2.4375")
        == QQ(39) / QQ(16)
    )

    print(
        "    PASS"
    )

    # --------------------------------------------------------
    # Projective normalization
    # --------------------------------------------------------

    print()
    print(
        "Test 1b: projective normalization"
    )

    assert (
        normalize_projective_vector(
            (
                QQ(1)/QQ(2),
                QQ(1),
                QQ(3)/QQ(2)
            )
        )
        == (1, 2, 3)
    )

    assert (
        normalize_projective_vector(
            (-1, -2, -3)
        )
        == (1, 2, 3)
    )

    assert (
        normalize_projective_vector(
            (2, 4, 6)
        )
        == (1, 2, 3)
    )

    print(
        "    PASS"
    )

    # --------------------------------------------------------
    # Undefined slope handling
    # --------------------------------------------------------

    print()
    print(
        "Test 1c: undefined slope handling"
    )

    # Three lines forming a triangle:
    #
    # x = 0
    # y = 0
    # z = 0
    #
    # gives 3 double points and cbar_1^2 = cbar_2 = 0.

    triangle = [
        (1, 0, 0),
        (0, 1, 0),
        (0, 0, 1),
    ]

    _, triangle_tk = intersection_data(
        triangle,
        store_points=True
    )

    triangle_slope = chern_slope(
        triangle,
        triangle_tk
    )

    assert triangle_slope is None

    print(
        "    PASS"
    )

    # --------------------------------------------------------
    # RT symbolic benchmark
    # --------------------------------------------------------

    print()
    print("Test 2: symbolic RT formulas")

    symbolic_check = (
        verify_RT_symbolically()
    )

    assert symbolic_check[
        "slope_correct"
    ]

    assert symbolic_check[
        "limit_correct"
    ]

    print(
        "    PASS"
    )

    # --------------------------------------------------------
    # RT brute-force benchmark
    # --------------------------------------------------------

    print()
    print(
        "Test 3: brute-force RT validation"
    )

    failures = verify_RT_numerically(
        N=RT_N
    )

    assert not failures

    print(
        "    PASS"
    )

    # --------------------------------------------------------
    # Slow-vs-fast incidence check
    # --------------------------------------------------------

    print()
    print(
        "Test 4: fast/slow incidence agreement"
    )

    result = analyze_family_at_n(
        "RT",
        3,
        store_points=True,
        run_slow_check=True
    )

    assert result[
        "slow_incidence_check"
    ]

    print(
        "    PASS"
    )

    print()
    print("#" * 100)

    print(
        "ALL SELF TESTS PASSED."
    )

    print("#" * 100)

    print()

    return True


# ============================================================
# 39. STARTUP SUMMARY
# ============================================================

def startup_summary():
    """
    Display the research environment and useful commands.
    """

    print()
    print("#" * 100)
    print("LINE ARRANGEMENT EXPLORER")
    print("#" * 100)

    print()
    print(
        "Exact coefficient field: QQ"
    )

    print(
        "Display precision:",
        DECIMAL_PRECISION,
        "bits"
    )

    print()
    print(
        "Known rational benchmark:"
    )

    print(
        "    19/8 =",
        decimal(
            KNOWN_RATIONAL_BENCHMARK,
            40
        )
    )

    print()
    print(
        "Conjectured endpoint:"
    )

    print(
        "    5/2 =",
        decimal(
            CONJECTURED_UPPER_ENDPOINT,
            40
        )
    )

    list_families()

    print()
    print("MOST USEFUL COMMANDS")
    print("--------------------")

    print(
        "    list_families()"
    )

    print(
        "    show_family('A')"
    )

    print(
        "    print_family_lines('A', 10)"
    )

    print(
        "    analyze_family_at_n('A', 10)"
    )

    print(
        "    search_family('A', N=100, verbose=False)"
    )

    print(
        "    print_slope_table('A', N=100)"
    )

    print(
        "    estimate_accumulation_point('A', N=100)"
    )

    print(
        "    scan_for_high_slopes(N=100)"
    )

    print(
        "    scan_near_target("
    )

    print(
        "        target=QQ(5)/2,"
    )

    print(
        "        tolerance=QQ(1)/1000,"
    )

    print(
        "        N=100"
    )

    print(
        "    )"
    )

    print(
        "    interpolate_tk('A', 3, N=50)"
    )

    print(
        "    interpolate_d('A', N=50)"
    )

    print(
        "    verify_RT_symbolically()"
    )

    print(
        "    verify_RT_numerically(N=10)"
    )

    print(
        "    run_self_tests()"
    )

    print()